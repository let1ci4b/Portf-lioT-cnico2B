package pets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Acessobd {
    private static Connection connection;
   
    public static Connection getConnection(){
        if(connection == null){
            try{
                //Class.forName("com.mysql.jdbc.Driver"); //para mysql
                Class.forName("org.postgresql.Driver");//para postgresql
                String host = "localhost";
                String port = "5432";
                String database = "postgres";
                String user = "postgres";
                String pass = "postgres";//digitar a senha do seu banco
                //String url = "jdbc:mysql://"+host+":"+port+"/"+database; //para mysql
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;//para postgresql
                connection = DriverManager.getConnection(url, user, pass);                
               
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        }
        else{
            try{
                connection.close();
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
 
    public static void salvar (Pets pets){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO pets (id, nome, idade, raca) values(?, ?, ?, ?)");
            ps.setString(1, pets.getId());
            ps.setString(2, pets.getNome());
            ps.setInt(3, pets.getIdade());
            ps.setString(4, pets.getRaça());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void deleta(String id){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM pets WHERE id = ?");
            ps.setString(1, id);
            ps.executeUpdate();
            }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void mudaSenhaUser(Pets pets){
        deleta(pets.getId());
        salvar(pets);
    }
    
    public static void vizualizaTabela(String tabela, String... atributos){
        try{
            Connection con = Acessobd.getConnection();  // realiza o acesso ao banco de dados 
            PreparedStatement ps = con.prepareStatement("SELECT * FROM "+ tabela); // faz o select from da tabela
            ResultSet res = ps.executeQuery(); // retorna um obejto com os valores da tabela
            String selectfrom = ""; // cria uma String grande para armazenar todos os valores do select from
            
            while(res.next()){ // varre as linhas da tabela
                for(String i : atributos){ // varre as colunas da tabela
                   selectfrom = selectfrom + " - " + res.getString(i); // adiciona os valores varridos à String selectfrom
                }
                selectfrom = selectfrom + "\n"; // pula uma linha após o conteúdo do selectfrom
            }
            System.out.println(selectfrom); // imprime as informações da tabela
                
        } catch(Exception e){
            e.printStackTrace(); // imprime a mensagem de erro caso haja exceção
    }
    }
     public static void atualizar (String idNovo, String idAntigo){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE pets SET id = ? WHERE id = ?");
            ps.setString(1, idNovo);
            ps.setString(2, idAntigo);
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
