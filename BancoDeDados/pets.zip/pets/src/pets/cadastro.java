package pets;


public class cadastro {

   
    public static void main(String[] args) {
        //QUESTÃO 3
        //Pets s = new Pets("12534871", "juno", 5, "labrador");
        //Acessobd.salvar(s);
        //Pets t = new Pets("12597210", "fred", 2, "gato persa");
        //Acessobd.salvar(t);
        //Pets u = new Pets("12597315", "clair", 1, "hamster chines");
        //Acessobd.salvar(u);
        
        Acessobd.vizualizaTabela("pets", "id", "nome", "idade", "raca");
    }
    
}
