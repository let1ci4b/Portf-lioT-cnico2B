package lanchonete;

public class Lanchonete {

    public static void main(String[] args) {
        TelaInicio inicio = new TelaInicio();
        inicio.setVisible(true);
    }
}