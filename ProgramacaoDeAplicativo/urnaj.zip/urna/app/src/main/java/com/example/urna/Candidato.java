package com.example.urna;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Candidato {
    String nome, cargo, numero;
    int quantvotos;

    public Candidato(String nome, String cargo, String numero, int quantvotos) {
        this.nome = nome;
        this.cargo = cargo;
        this.numero = numero;
        this.quantvotos = quantvotos;
    }

    public Candidato() {
    }

    public void salvarBD() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("Candidato").child(String.valueOf(nome)).setValue(this);

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getQuantvotos() {
        return quantvotos;
    }

    public void setQuantvotos(int quantvotos) {
        this.quantvotos = quantvotos;
    }
}