package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
    }

    public void logar(View v){
        Intent l = new Intent(this, Login_cadastro.class);
        startActivity(l);
        Login_cadastro.tela = 1;
    }

    public void cadastro(View v){
        Intent c = new Intent(this, Login_cadastro.class);
        startActivity(c);
        Login_cadastro.tela = 2;
    }
}