package com.example.animal_teste__;

public class Resposta_agrarias {
    String texto;
    int Agronomia = 0;
    int Ecologia = 0;
    int Engenharia_agricola = 0;
    int Engenharia_pesca = 0;
    int Geologia = 0;

    public Resposta_agrarias(String texto, int agronomia, int ecologia, int engenharia_agricola, int engenharia_pesca, int geologia) {
        this.texto = texto;
        Agronomia = agronomia;
        Ecologia = ecologia;
        Engenharia_agricola = engenharia_agricola;
        Engenharia_pesca = engenharia_pesca;
        Geologia = geologia;
    }
}
