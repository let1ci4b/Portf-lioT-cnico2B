package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

public class Resultado extends AppCompatActivity {
    TextView nomearea, desc;
    ImageView img;
    static ImageView fotoPerfil;

    static int[] areas_geral = new int[8];
    static int[] areas_terra = new int[6];
    static int[] areas_biologicas = new int[5];
    static int[] areas_engenharias = new int[6];
    static int[] areas_saude = new int[6];
    static int[] areas_agrarias = new int[5];
    static int[] areas_artes = new int[7];
    static int[] areas_sociais = new int[5];
    static int[] areas_humanas = new int[8];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        getSupportActionBar().hide();
        nomearea = findViewById(R.id.resultado);
        desc = findViewById(R.id.descricao);
        img = findViewById(R.id.imagem);
        int[] areas_terra_ord = Arrays.copyOf(areas_terra, areas_terra.length);
        int[] areas_biologicas_ord = Arrays.copyOf(areas_biologicas, areas_biologicas.length);
        int[] areas_engenharias_ord = Arrays.copyOf(areas_engenharias, areas_engenharias.length);
        int[] areas_saude_ord = Arrays.copyOf(areas_saude, areas_saude.length);
        int[] areas_agrarias_ord = Arrays.copyOf(areas_agrarias, areas_agrarias.length);
        int[] areas_artes_ord = Arrays.copyOf(areas_artes, areas_artes.length);
        int[] areas_sociais_ord = Arrays.copyOf(areas_sociais, areas_sociais.length);
        int[] areas_humanas_ord = Arrays.copyOf(areas_humanas, areas_humanas.length);
        int[] areas_geral_ord = Arrays.copyOf(areas_geral, areas_geral.length);

        Arrays.sort(areas_terra_ord);
        Arrays.sort(areas_biologicas_ord);
        Arrays.sort(areas_engenharias_ord);
        Arrays.sort(areas_saude_ord);
        Arrays.sort(areas_agrarias_ord);
        Arrays.sort(areas_artes_ord);
        Arrays.sort(areas_sociais_ord);
        Arrays.sort(areas_humanas_ord);
        Arrays.sort(areas_geral_ord);

        int ultimo1 = areas_geral_ord[areas_geral_ord.length -1];
        for (int i = 0; i < areas_geral_ord.length; i++) {
            if (Tela_perguntas.opcao == 1) {
                if (areas_geral[i] == ultimo1) {
                    if (i == 0) {
                        nomearea.setText("CIÊNCIAS EXATAS E DA TERRA");
                        img.setImageResource(R.drawable.cieexatas);
                        desc.setText("É uma área indicada para pessoas que gostam de raciocínio lógico, fórmulas e números.");
                        Perfil.res = 0;
                    }
                    else if (i == 1) {
                        nomearea.setText("CIÊNCIAS BIOLÓGICAS");
                        img.setImageResource(R.drawable.biologicas);
                        desc.setText("É uma área de estudo da vida, demanda muita experimentação e pesquisa, além de grande habilidade de foco e afinidade com animais e pessoas.");
                        Perfil.res = 1;
                    }
                    else if (i == 2) {
                        nomearea.setText("ENGENHARIAS");
                        img.setImageResource(R.drawable.engenharias);
                        desc.setText("Além de afinidade com as ciências exatas, a engenharia também demanda uma grande capacidade de criar e construir.");
                        Perfil.res = 2;
                    }
                    else if (i == 3) {
                        nomearea.setText("CIÊNCIAS DA SAÚDE");
                        img.setImageResource(R.drawable.ciesaude);
                        desc.setText("É uma área focada em diagnósticos e na busca pelo bem-estar. Necessita de afinidade com pessoas, atenção aos detalhes e ser meticuloso.");
                        Perfil.res = 3;
                    }
                    else if (i == 4) {
                        nomearea.setText("CIÊNCIAS AGRÁRIAS");
                        img.setImageResource(R.drawable.cieagrarias);
                        desc.setText("É uma área que mistura agronomia com exatas e biológicas. É recomendada para quem gosta de lidar com preservação, questões ambientais e desenvolvimento econômico.");
                        Perfil.res = 4;
                    }
                    else if (i == 5) {
                        nomearea.setText("LINGUÍSTICA, LETRAS E ARTES");
                        img.setImageResource(R.drawable.letrasartes);
                        desc.setText("É uma área focada na comunicação e expressão que valoriza o complexo pensamento humano, mas não deixa de acompanhar as novas tendências e tecnologias.");
                        Perfil.res = 5;
                    }
                    else if (i == 6) {
                        nomearea.setText("CIÊNCIAS SOCIAIS APLICADAS");
                        img.setImageResource(R.drawable.ciesociais);
                        desc.setText("É uma área ligada à sociedade e à coletividade. São cursos interdisciplinares e indicados para pessoas questionadoras com afinidade por leitura e escrita.");
                        Perfil.res = 6;
                    }
                    else if (i == 7) {
                        nomearea.setText("CIÊNCIAS HUMANAS");
                        img.setImageResource(R.drawable.ciehumanas);
                        desc.setText("É uma área focada no ser humano, é indicada para pessoas com senso crítico apurado e fortes habilidades de comunicação e observação.");
                        Perfil.res = 7;
                    }
                }
            }
        }

        int ultimo = areas_terra_ord[areas_terra_ord.length - 1];
        for (int i = 0; i < areas_terra_ord.length; i++) {
            if (Tela_perguntas.opcao == 2) {
                if (areas_terra[i] == ultimo) {
                    if (i == 0) {
                        nomearea.setText("CIÊNCIAS DA COMPUTAÇÃO");
                        img.setImageResource(R.drawable.ciecomputacao);
                        desc.setText("O profissional necessita aptidão para lidar com dispositivos tecnológicos. É preciso ser dinâmico, competitivo e trabalhar bem sob pressão.");
                    }

                    else if (i == 1) {
                        nomearea.setText("CIÊNCIAS NATURAIS");
                        img.setImageResource(R.drawable.cienaturais);
                        desc.setText("O profissional precisa gostar de matemática, física, biologia e química, ter afinidade por pesquisas, boa comunicação, objetividade e clareza.");
                    }

                    else if (i == 2) {
                        nomearea.setText("FÍSICA");
                        img.setImageResource(R.drawable.fisica);
                        desc.setText("O profissional deve ser organizado, concentrado e ter curiosidade e interesse em estudar as características e propriedades da matéria.");
                    }

                    else if (i == 3) {
                        nomearea.setText("MATEMÁTICA");
                        img.setImageResource(R.drawable.matematica);
                        desc.setText("O profissional deve gostar de números, cálculos e de resolver problemas. É necessário ter boa comunicação, objetividade, clareza, disciplina e organização.");
                    }

                    else if (i == 4) {
                        nomearea.setText("QUÍMICA");
                        img.setImageResource(R.drawable.quimica);
                        desc.setText("O profissional deve ser curioso e dinâmico e manter-se atualizado em relação aos avanços científicos e tecnológicos desta área. ");
                    }

                    else if (i == 5) {
                        nomearea.setText("ASTRONOMIA");
                        img.setImageResource(R.drawable.astronomia);
                        desc.setText("O curso de astronomia aborda o estudo da estrutura e da história do universo, de seus astros e do Sistema Solar, além dos estudos dos cientistas da área.");
                    }
                }
            }
        }

        int ultimo2 = areas_biologicas_ord[areas_biologicas_ord.length - 1];
        for (int i = 0; i < areas_biologicas_ord.length; i++) {
            if (Tela_perguntas.opcao == 5) {
                if (areas_biologicas[i] == ultimo2) {
                    if (i == 0) {
                        nomearea.setText("GESTÃO AMBIENTAL");
                        img.setImageResource(R.drawable.gestaoambiental);
                        desc.setText("O profissional precisa disseminar práticas sustentáveis e se comunicar ao equilibrar os interesses empresariais e necessidades ecológicas.");
                    }
                    else if (i == 1) {
                        nomearea.setText("VIGILÂNCIA SANITÁRIA");
                        img.setImageResource(R.drawable.vigsanitaria);
                        desc.setText("O profissional avalia riscos e danos à saúde e ao meio ambiente. Além disso, compõe equipes que atuam no processo de epidemiologia, ambiental e saúde.");
                    }
                    else if (i == 2) {
                        nomearea.setText("BIOMEDICINA");
                        img.setImageResource(R.drawable.biomedicina);
                        desc.setText("O profissional estuda os seres vivos, a relação entre eles e o meio ambiente, além dos processos e mecanismos que regulam a vida.");
                    }
                    else if (i == 3) {
                        nomearea.setText("MEDICINA VETERINÁRIA");
                        img.setImageResource(R.drawable.veterinaria);
                        desc.setText("O profissional precisa ter empatia e capacidade de trabalhar sob pressão. Eles são capazes de intervir em todos os setores associados à saúde animal.");
                    }
                    else if (i == 4) {
                        nomearea.setText("NUTRIÇÃO");
                        img.setImageResource(R.drawable.nutricao);
                        desc.setText("O profissional atua na investigação, promoção, recuperação e manutenção da relação do homem com a alimentação.");
                    }
                }
            }
        }

        int ultimo3 = areas_engenharias_ord[areas_engenharias_ord.length - 1];
        for (int i = 0; i < areas_engenharias_ord.length; i++) {
            if (Tela_perguntas.opcao == 7) {
                if (areas_engenharias[i] == ultimo3) {
                    if (i == 0) {
                        nomearea.setText("ENGENHARIA CIVIL");
                        img.setImageResource(R.drawable.engcivil);
                        desc.setText("O profissional deve trabalhar com números, ser organizado e meticuloso. Eles são capazes de elaborar e executar projetos e obras.");
                    }
                    else if (i == 1) {
                        nomearea.setText("ENGENHARIA ELÉTRICA");
                        img.setImageResource(R.drawable.engeletrica);
                        desc.setText("O profissional deve gostar de matemática, física e tecnologia. Ele é capaz de lidar com a geração, transmissão e distribuição de energia elétrica.");
                    }
                    else if (i == 2) {
                        nomearea.setText("ENGENHARIA AMBIENTAL");
                        img.setImageResource(R.drawable.engambiental);
                        desc.setText("O profissional deve ter interesse em controle ambiental. Ele atua na análise, manejo e monitoramento de problemas ambientais urbanos e rurais.");
                    }
                    else if (i == 3) {
                        nomearea.setText("ENGENHARIA DE PRODUÇÃO");
                        img.setImageResource(R.drawable.engproducao);
                        desc.setText("O profissional deve saber organizar processos e enfrentar desafios, ser lógico e ter afinidade com ciências exatas e tecnologia.");
                    }
                    else if (i == 4) {
                        nomearea.setText("ENGENHARIA QUÍMICA");
                        img.setImageResource(R.drawable.engquimica);
                        desc.setText("O profissional precisa de afinidade com laboratórios, curiosidade e interesse em experimentos e gostar de ciências exatas e química.");
                    }
                    else if (i == 5) {
                        nomearea.setText("ENGENHARIA DE SOFTWARE");
                        img.setImageResource(R.drawable.engsoftware);
                        desc.setText("O profissional dessa área precisa possuir foco, interesse em tecnologias e processos de desenvolvimento de softwares.");
                    }
                }
            }
        }

        int ultimo4 = areas_saude_ord[areas_saude_ord.length - 1];
        for (int i = 0; i < areas_saude_ord.length; i++) {
            if (Tela_perguntas.opcao == 9) {
                if (areas_saude[i] == ultimo4) {
                    if (i == 0) {
                        nomearea.setText("MEDICINA");
                        img.setImageResource(R.drawable.medicina);
                        desc.setText("O profissional deve ser ético e prático. Ele busca a natureza e as causas das doenças para propor a cura e prevenção.");
                    }
                    else if (i == 1) {
                        nomearea.setText("ENFERMAGEM");
                        img.setImageResource(R.drawable.enfermagem);
                        desc.setText("Esse profissional cuida de pessoas, é proativo, precisa ser humanista, ter controle das próprias emoções e caráter prático.");
                    }
                    else if (i == 2) {
                        nomearea.setText("FARMÁCIA");
                        img.setImageResource(R.drawable.farmacia);
                        desc.setText("O profissional deve ser humanista, ético e ter senso de responsabilidade. Ele atua na cadeia produtiva das áreas de medicamentos.");
                    }
                    else if (i == 3) {
                        nomearea.setText("ODONTOLOGIA");
                        img.setImageResource(R.drawable.odontologia);
                        desc.setText("O profissional deve ter poder de concentração, ser paciente e detalhista e ter interesse no bem estar bucal dos pacientes.");
                    }
                    else if (i == 4) {
                        nomearea.setText("PSICOLOGIA");
                        img.setImageResource(R.drawable.psicologia);
                        desc.setText("O profissional deve ter apreço pelas relações humanas, gostar de se comunicar, interagir, ouvir e analisar pessoas.");
                    }
                    else if (i == 5) {
                        nomearea.setText("EDUCAÇÃO FÍSICA");
                        img.setImageResource(R.drawable.edfisica);
                        desc.setText("Os profissionais dessa área devem ser capazes de promover a saúde e a capacidade física por meio do ensino e prática de atividades corporais");
                    }
                }
            }
        }

        int ultimo5 = areas_agrarias_ord[areas_agrarias_ord.length - 1];
        for (int i = 0; i < areas_agrarias_ord.length; i++) {
            if (Tela_perguntas.opcao == 6) {
                if (areas_agrarias[i] == ultimo5) {
                    if (i == 0) {
                        nomearea.setText("AGRONOMIA");
                        img.setImageResource(R.drawable.agronomia);
                        desc.setText("O profissional está sempre em contato com os animais e com o campo, possui capacidade de adaptação e de resolver problemas.");
                    }
                    else if (i == 1) {
                        nomearea.setText("ECOLOGIA");
                        img.setImageResource(R.drawable.ecologia);
                        desc.setText("Esse profissional explora as relações existentes entre os organismos vivos e seu ambiente e como preservar recursos ambientais.");
                    }
                    else if (i == 2) {
                        nomearea.setText("ENGENHARIA AGRÍCOLA");
                        img.setImageResource(R.drawable.engagricola);
                        desc.setText("O profissional possui visão integrada do desenvolvimento da do sistema agrícola e aplica as ciências exatas e a tecnologia à agricultura.");
                    }
                    else if (i == 3) {
                        nomearea.setText("ENGENHARIA DE PESCA");
                        img.setImageResource(R.drawable.engpesca);
                        desc.setText("O profissional dessa área planeja e desenvolve as atividades relacionadas ao cultivo, preservação e comercialização de peixes.");
                    }
                    else if (i == 4) {
                        nomearea.setText("GEOLOGIA");
                        img.setImageResource(R.drawable.geologia);
                        desc.setText("O profissional deve gostar de estudar e realizar pesquisas. Ele adquire uma boa compreensão da natureza e seus fenômenos.");
                    }
                }
            }
        }

        int ultimo6 = areas_artes_ord[areas_artes_ord.length - 1];
        for (int i = 0; i < areas_artes_ord.length; i++) {
            if (Tela_perguntas.opcao == 8) {
                if (areas_artes[i] == ultimo6) {
                    if (i == 0) {
                        nomearea.setText("ARTES");
                        img.setImageResource(R.drawable.artes);
                        desc.setText("O profissional de artes possui habilidades de percepção, reflexão, produção e crítica. Ele promove a produção e a criação artística.");
                    }
                    else if (i == 1) {
                        nomearea.setText("DANÇA");
                        img.setImageResource(R.drawable.danca);
                        desc.setText("O profissional precisa gostar de se movimentar e de explorar os limites do corpo, ter sensibilidade estética e capacidade de comunicação.");
                    }
                    else if (i == 2) {
                        nomearea.setText("DESIGN GRÁFICO");
                        img.setImageResource(R.drawable.design);
                        desc.setText("O profissional deve ter afinidade com desenho e tecnologia, sensibilidade, curiosidade, criatividade e senso estético.");
                    }
                    else if (i == 3) {
                        nomearea.setText("CINEMA");
                        img.setImageResource(R.drawable.cinema);
                        desc.setText("O profissional precisa ter criatividade, ser comunicativo e ter interesse por tecnologias relacionadas à produção audiovisual.");
                    }
                    else if (i == 4) {
                        nomearea.setText("MÚSICA");
                        img.setImageResource(R.drawable.musica);
                        desc.setText("O profissional deve ter a capacidade de expressão e comunicação, ouvido apurado e conhecimento técnico dos instrumentos e da voz.");
                    }
                    else if (i == 5) {
                        nomearea.setText("LINGUÍSTICA");
                        img.setImageResource(R.drawable.linguistica);
                        desc.setText("Os profissionais estudam e refletem criticamente sobre o funcionamento e os processos linguísticos da língua e da linguagem.");
                    }
                    else if (i == 6) {
                        nomearea.setText("LETRAS");
                        img.setImageResource(R.drawable.letras);
                        desc.setText("Os profissionais são capazes de entender sobre a estrutura das línguas, sua história, e cultura a partir da linguagem.");
                    }
                }
            }
        }

        int ultimo7 = areas_sociais_ord[areas_sociais_ord.length - 1];
        for (int i = 0; i < areas_sociais_ord.length; i++) {
            if (Tela_perguntas.opcao == 4) {
                if (areas_sociais[i] == ultimo7) {
                    if (i == 0) {
                        nomearea.setText("ADMINISTRAÇÃO");
                        img.setImageResource(R.drawable.administracao);
                        desc.setText("O profissional dessa área faz parte do processo de planejar e controlar o uso de recursos para alcançar os objetivos definidos.");
                    }
                    else if (i == 1) {
                        nomearea.setText("BIBLIOTECONOMIA");
                        img.setImageResource(R.drawable.biblioteconomia);
                        desc.setText("O profissional precisa ser organizado, pois atua como um administrador de dados, processando e divulgando informações.");
                    }
                    else if (i == 2) {
                        nomearea.setText("CIÊNCIAS CONTÁBEIS");
                        img.setImageResource(R.drawable.contabeis);
                        desc.setText("O profissional atua no processo de administração das empresas, tendo papel crucial para orientar o empresário.");
                    }
                    else if (i == 3) {
                        nomearea.setText("COMÉRCIO EXTERIOR");
                        img.setImageResource(R.drawable.comexterior);
                        desc.setText("O profissional compreende as técnicas de compra e venda de produtos e serviços entre empresas e governos de diferentes países.");
                    }
                    else if (i == 4) {
                        nomearea.setText("DIREITO");
                        img.setImageResource(R.drawable.direito);
                        desc.setText("O profissional cuida da aplicação e do cumprimento das normas jurídicas para organizar e manter a ordem na sociedade.");
                    }
                }
            }
        }

        int ultimo8 = areas_humanas_ord[areas_humanas_ord.length - 1];
        for (int i = 0; i < areas_humanas_ord.length; i++) {
            if (Tela_perguntas.opcao == 3) {
                if (areas_humanas[i] == ultimo8) {
                    if (i == 0) {
                        nomearea.setText("FILOSOFIA");
                        img.setImageResource(R.drawable.filosofia);
                        desc.setText("Esses profissionais trabalham com pesquisa e produção teórica. Eles questionam e investigam a natureza e a essência do universo.");
                    }
                    else if (i == 1) {
                        nomearea.setText("HISTÓRIA");
                        img.setImageResource(R.drawable.historia);
                        desc.setText("O profissional dessa área atua em diferentes campos de produção e difusão do conhecimento histórico.");
                    }
                    else if (i == 2) {
                        nomearea.setText("PEDAGOGIA");
                        img.setImageResource(R.drawable.pedagogia);
                        desc.setText("O profissional é responsável por acompanhar crianças e adultos em seus processos de desenvolvimento intelectual e social.");
                    }
                    else if (i == 3) {
                        nomearea.setText("GEOGRAFIA");
                        img.setImageResource(R.drawable.geografia);
                        desc.setText("Os profissionais são estudiosos da superfície terrestre e da ocupação do homem no planeta, seus efeitos e características.");
                    }
                    else if (i == 4) {
                        nomearea.setText("JORNALISMO");
                        img.setImageResource(R.drawable.jornalismo);
                        desc.setText("O profissional produz notícias para meios de comunicação. Ele é responsável pela investigação de informações de interesse público.");
                    }
                    else if (i == 5) {
                        nomearea.setText("GASTRONOMIA");
                        img.setImageResource(R.drawable.gastronomia);
                        desc.setText("O profissional elabora cardápios, supervisiona o funcionamento da cozinha, negocia com fornecedores e controla o orçamento.");
                    }
                    else if (i == 6) {
                        nomearea.setText("MARKETING");
                        img.setImageResource(R.drawable.marketing);
                        desc.setText("Os profissionais são criativos, imparciais, atualizados sobre o mercado e sabem aproveitar as oportunidades do mercado.");
                    }
                    else if (i == 7) {
                        nomearea.setText("LOGÍSTICA");
                        img.setImageResource(R.drawable.logistica);
                        desc.setText("O profissional atua com o objetivo de organizar processos logísticos de compra ou venda. Eles gerenciam e coordenam muitas situações.");
                    }
                }
            }
        }
    }

    public void volta(View v){
        Intent volta = new Intent(this, Teste_opcoes.class);
        startActivity(volta);
    }
}