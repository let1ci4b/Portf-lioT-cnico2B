package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Teste_areas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_teste_areas);
    }

    public void exatas(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 2;
    }

    public void humanas(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 3;
    }

    public void sociais(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 4;
    }

    public void biologicas(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 5;
    }

    public void agrarias(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 6;
    }

    public void engenharias(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 7;
    }

    public void linguistica(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 8;
    }

    public void saude(View view) {
        Intent ex = new Intent(this, Tela_perguntas.class);
        startActivity(ex);
        Tela_perguntas.opcao = 9;
    }
}
