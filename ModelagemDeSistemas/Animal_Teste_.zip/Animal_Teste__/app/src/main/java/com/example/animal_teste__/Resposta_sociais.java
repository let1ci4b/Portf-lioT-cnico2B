package com.example.animal_teste__;

public class Resposta_sociais {
    String texto;
    int Administracao = 0;
    int Biblioteconomia = 0;
    int Ciencias_contabeis = 0;
    int Comercio_exterior = 0;
    int Direito = 0;

    public Resposta_sociais(String texto, int administracao, int biblioteconomia, int ciencias_contabeis, int comercio_exterior, int direito) {
        this.texto = texto;
        Administracao = administracao;
        Biblioteconomia = biblioteconomia;
        Ciencias_contabeis = ciencias_contabeis;
        Comercio_exterior = comercio_exterior;
        Direito = direito;
    }
}
