package com.example.animal_teste__;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login_cadastro extends AppCompatActivity {
    static int tela;
    EditText em, sh, emc;
    ImageView ce, cs, csc, tcadastrar, tlogin, entrar, cadastrar, sem_cadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_cadastro);
        getSupportActionBar().hide();
        em = findViewById(R.id.nome_email);
        sh = findViewById(R.id.senha);
        emc = findViewById(R.id.email);
        ce = findViewById(R.id.campo_email_nome);
        cs = findViewById(R.id.campo_email);
        csc = findViewById(R.id.campo_senha);
        tcadastrar = findViewById(R.id.cadastro_logo);
        tlogin = findViewById(R.id.login_logo);
        entrar = findViewById(R.id.entrar);
        cadastrar = findViewById(R.id.cadastrar);
        sem_cadastro = findViewById(R.id.sem_cadastro);
        organiza();
    }

    public void organiza() {
        if (tela == 1) {
            em.setHint("Email ou nome");
            sh.setHint("Senha");
            emc.setVisibility(View.INVISIBLE);
            tcadastrar.setVisibility(View.INVISIBLE);
            cs.setVisibility(View.GONE);
            cadastrar.setVisibility(View.INVISIBLE);
        } else if (tela == 2) {
            em.setHint("Nome de usuário");
            sh.setHint("Senha");
            emc.setHint("Email");
            tlogin.setVisibility(View.INVISIBLE);
            entrar.setVisibility(View.INVISIBLE);
            sem_cadastro.setVisibility(View.INVISIBLE);
        }
    }

    public void sem_cadastro(View view){
        emc.setVisibility(View.VISIBLE);
        tcadastrar.setVisibility(View.VISIBLE);
        cs.setVisibility(View.VISIBLE);
        cadastrar.setVisibility(View.VISIBLE);
        em.setHint("Nome de usuário");
        sh.setHint("Senha");
        emc.setHint("Email");
        tlogin.setVisibility(View.INVISIBLE);
        entrar.setVisibility(View.INVISIBLE);
        sem_cadastro.setVisibility(View.INVISIBLE);
    }

    public void print(String n) {
        Toast.makeText(this, n, Toast.LENGTH_SHORT).show();
    }

    public void entrar(View v){
        Intent e = new Intent(this, Teste_opcoes.class);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Usuario");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nome = em.getText().toString();
                String senha = sh.getText().toString();
                String email = em.getText().toString();
                boolean teste = false;

                for (DataSnapshot usuario : snapshot.getChildren()) {
                    if (usuario.getValue(Usuario.class).getNome().equals(nome)  && usuario.getValue(Usuario.class).getSenha().equals(senha)) {
                        teste = true;
                        Perfil.nome = nome;
                        Perfil.email = usuario.getValue(Usuario.class).getEmail();
                        startActivity(e);
                    }
                    if (usuario.getValue(Usuario.class).getSenha().equals(senha) && usuario.getValue(Usuario.class).getEmail().equals(email)) {
                        teste = true;
                        Perfil.nome = nome;
                        Perfil.email = usuario.getValue(Usuario.class).getEmail();
                        startActivity(e);
                    }
                }
                if (teste == false) {
                    if (nome.equals("") || senha.equals("")) {
                        print("Preencha os dados corretamente");
                    } else if (teste == false){
                        print("Usuário não cadastrado");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void cadastrar(View view){
        Intent c = new Intent(this, Teste_opcoes.class);
        if (em.getText().toString().equals("") || sh.getText().toString().equals("") || emc.getText().toString().equals("")){
            Toast.makeText(this, "Preencha os dados corretamente", Toast.LENGTH_LONG).show();
        } else {
            startActivity(c);
            finish();

            String nome = em.getText().toString();
            String senha = sh.getText().toString();
            String email = emc.getText().toString();

            Usuario u = new Usuario(nome, senha, email);
            u.salvar();

            Perfil.nome = u.getNome();
            Perfil.email = u.getEmail();
        }
    }
}