package com.example.animal_teste__;

public class Resposta_linguistica {
    String texto;
    int Artes = 0;
    int Danca = 0;
    int Design_grafico = 0;
    int Cinema = 0;
    int Musica = 0;
    int Linguistica= 0;
    int Letras = 0;

    public Resposta_linguistica(String texto, int artes, int danca, int design_grafico, int cinema, int musica, int linguistica, int letras) {
        this.texto = texto;
        Artes = artes;
        Danca = danca;
        Design_grafico = design_grafico;
        Cinema = cinema;
        Musica = musica;
        Linguistica = linguistica;
        Letras = letras;
    }
}
