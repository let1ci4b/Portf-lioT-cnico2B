package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Tela_perguntas extends AppCompatActivity {
    static int opcao;
    Button prox;
    TextView curso, pgt;
    RadioButton r1, r2, r3, r4, r5, r6, r7, r8;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_tela_perguntas);
        curso = findViewById(R.id.curso);
        prox = findViewById(R.id.prox);
        pgt = findViewById(R.id.pgt);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        r4 = findViewById(R.id.r4);
        r5 = findViewById(R.id.r5);
        r6 = findViewById(R.id.r6);
        r7 = findViewById(R.id.r7);
        r8 = findViewById(R.id.r8);
        b1 = findViewById(R.id.b1);

        if (opcao == 1) {
            curso.setText("Áreas do Conhecimento");
            pgt.setText("Quando pensa na profissão perfeita, o mais importante para você é:");
            r1.setText("Poder usar raciocínio lógico e resolver problemas.");
            r2.setText("Ajudar o bem-estar das pessoas.");
            r3.setText("Trabalhar em algo que esteja em evidência na economia.");
            r4.setText("Fazer algo que gosto, me expressando.");
            r5.setText("Poder atuar em minha comunidade.");
            r6.setText("Quero trabalhar com pessoas.");
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 2){
            curso.setText("Ciências Exatas e da Terra");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("A oportunidade de trabalhar em um laboratório.");
            r2.setText("Explorar as grandes áreas da natureza.");
            r3.setText("Estudar a estrutura do universo e do espaço sideral.");
            r4.setText("Realizar muitas pesquisas.");
            r5.setText("Poder resolver problemas diversos.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 3){
            curso.setText("Ciências Humanas");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Realizar pesquisas e investigar.");
            r2.setText("Trabalhar em algo em alta no mercado.");
            r3.setText("Divulgação de informações.");
            r4.setText("Auxiliar no ensinamento e aprendizagem.");
            r5.setText("Trabalhar com comida.");
            r6.setText("Organizar e gerenciar situações.");
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 4){
            curso.setText("Ciências Sociais Aplicadas");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("O gerenciamento de dados e informações.");
            r2.setText("Gerir negócios, pessoas ou recursos.");
            r3.setText("Poder interagir com o exterior.");
            r4.setText("Atuar na regularização da sociedade.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 5){
            curso.setText("Ciências Biológicas");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Poder desenvolver e encontrar curas.");
            r2.setText("O trabalho com animais.");
            r3.setText("Colaborar na saúde do indivíduo e sociedade.");
            r4.setText("Atuar na sustentabilidade do ambiente.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 6){
            curso.setText("Ciências Agrárias");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Realizar mapeamentos de terreno.");
            r2.setText("Atuar no armazenamento do setor agropecuário.");
            r3.setText("Atuar no desenvolvimento da agropecuária.");
            r4.setText("A preservação do ambiente e habitats.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 7){
            curso.setText("Engenharias");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Resolver problemas usando tecnologias.");
            r2.setText("Desenvolver novas formas de produção.");
            r3.setText("Fazer parte da construção de obras.");
            r4.setText("Atuar com políticas em relação ao ambiente.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 8){
            curso.setText("Linguística, letras e artes");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Compreender as histórias, culturas e estruturas por trás dos idiomas.");
            r2.setText("Utilizar tecnologias para criações.");
            r3.setText("Desenhar.");
            r4.setText("Comunicar-me de maneiras diferentes.");
            r5.setText("Compreender os processos linguísticos.");
            r6.setText("Trabalhar em algo em alta no mercado.");
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (opcao == 9){
            curso.setText("Ciências da Saúde");
            pgt.setText("Qual destes mais te interessa?");
            r1.setText("Realizar cirurgias.");
            r2.setText("Atuar em laboratórios.");
            r3.setText("Analisar e entender fenômenos psíquicos e de comportamento.");
            r4.setText("Poder atuar na linha de frente da saúde.");
            r5.setText("Promover saúde e capacidade física.");
            r6.setText("Auxiliar no tratamento de portadores de deficiência.");
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }
    }

    public void muda_tela(View view) {
        Intent mt = new Intent(this, Questao.class);
        if (opcao == 1) {
            if (r1.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] += 1;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 1;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 2;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 1;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 1;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 2) {
            if (r1.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 1;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 2;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 2;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_terra[0] += 1;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 2;
                Resultado.areas_terra[3] += 1;
                Resultado.areas_terra[4] += 2;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_terra[0] += 2;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 2;
                Resultado.areas_terra[3] += 2;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 3) {
            if (r1.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 2;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 2;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 2;
                Resultado.areas_humanas[7] += 2;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 2;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 1;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 2;
                Resultado.areas_humanas[2] += 2;
                Resultado.areas_humanas[3] += 2;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 2;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 1;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 4) {
            if (r1.isChecked()) {
                Resultado.areas_sociais[0] += 2;
                Resultado.areas_sociais[1] += 2;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_sociais[0] += 1;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 2;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 2;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 5) {
            if (r1.isChecked()) {
                Resultado.areas_biologicas[0] += 0;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 2;
                Resultado.areas_biologicas[3] += 1;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_biologicas[0] += 1;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 2;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_biologicas[0] += 1;
                Resultado.areas_biologicas[1] += 2;
                Resultado.areas_biologicas[2] += 1;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_biologicas[0] += 2;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 6) {
            if (r1.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 0;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_agrarias[0] += 1;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 2;
                Resultado.areas_agrarias[3] += 1;
                Resultado.areas_agrarias[4] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_agrarias[0] += 2;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 1;
                Resultado.areas_agrarias[3] += 2;
                Resultado.areas_agrarias[4] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 2;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 1;
                Resultado.areas_agrarias[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 7) {
            if (r1.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 0;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 2;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_engenharias[0] += 2;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 0;
                Resultado.areas_engenharias[2] += 2;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 1;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 8) {
            if (r1.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 1;
                Resultado.areas_artes[6] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_artes[0] += 1;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 2;
                Resultado.areas_artes[3] += 2;
                Resultado.areas_artes[4] += 1;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_artes[0] += 2;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 1;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_artes[0] += 2;
                Resultado.areas_artes[1] += 2;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 2;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 2;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 2;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 1;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            }
            else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (opcao == 9) {
            if (r1.isChecked()) {
                Resultado.areas_saude[0] += 2;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 2;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_saude[0] += 1;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 2;
                Resultado.areas_saude[3] += 1;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 2;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_saude[0] += 1;
                Resultado.areas_saude[1] += 2;
                Resultado.areas_saude[2] += 1;
                Resultado.areas_saude[3] += 1;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 2;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_saude[0] += 1;
                Resultado.areas_saude[1] += 1;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 2;
                Resultado.areas_saude[5] += 2;
                startActivity(mt);
            }
            else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
    }
}