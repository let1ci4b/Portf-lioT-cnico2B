package com.example.animal_teste__;

public class Resposta_biologicas {
    String texto;
    int Gestao_ambiental = 0;
    int Vigilancia_sanitaria = 0;
    int Biomedicina = 0;
    int Medicina_veterinaria = 0;
    int Nutricao = 0;

    public Resposta_biologicas(String texto, int gestao_ambiental, int vigilancia_sanitaria, int biomedicina, int medicina_veterinaria, int nutricao) {
        this.texto = texto;
        Gestao_ambiental = gestao_ambiental;
        Vigilancia_sanitaria = vigilancia_sanitaria;
        Biomedicina = biomedicina;
        Medicina_veterinaria = medicina_veterinaria;
        Nutricao = nutricao;
    }
}
