package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Questao11 extends AppCompatActivity {
        TextView curso, pgt;
        RadioButton r1, r2, r3, r4, r5, r6, r7, r8;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_questao11);
            getSupportActionBar().hide();
            curso = findViewById(R.id.curso);
            pgt = findViewById(R.id.pgt);
            r1 = findViewById(R.id.r1);
            r2 = findViewById(R.id.r2);
            r3 = findViewById(R.id.r3);
            r4 = findViewById(R.id.r4);
            r5 = findViewById(R.id.r5);
            r6 = findViewById(R.id.r6);
            r7 = findViewById(R.id.r7);
            r8 = findViewById(R.id.r8);

            pgt.setText("Estaria disposto em passar anos estudando e evoluindo para seu trabalho?");
            curso.setText("Áreas do Conhecimento");
            r1.setText("Estou disposto a estudar e desenvolver novas habilidades em um curto período de tempo.");
            r2.setText("Desejo evoluir habilidades que já possuo em um curto período de tempo.");
            r3.setText("Estou disposto a estudar e desenvolver novas habilidades pelo tempo que for necessário.");
            r4.setText("Quero trabalhar apenas com o que já possuo.");
            r5.setText("Estou disposto a evoluir as habilidades que já possuo pelo tempo que for necessário.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        public void muda_tela11(View v){
            Intent mt = new Intent(this, Questao12.class);
            if(r1.isChecked()){
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 1;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 1;
                startActivity(mt);
            }
            else if(r2.isChecked()){
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] -= 1;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] -= 1;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            }
            else if (r3.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 1;
                startActivity(mt);
            }
            else if (r4.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 1;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            }
            else if (r5.isChecked()){
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 1;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onBackPressed() {
            Toast.makeText(this, "Não é possível voltar", Toast.LENGTH_SHORT).show();
        }
    }