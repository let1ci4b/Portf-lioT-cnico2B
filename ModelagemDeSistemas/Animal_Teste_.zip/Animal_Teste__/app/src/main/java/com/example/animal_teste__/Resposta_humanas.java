package com.example.animal_teste__;

public class Resposta_humanas {
    String texto;
    int Filosofia = 0;
    int Historia = 0;
    int Pedagogia = 0;
    int Geografia = 0;
    int Jornalismo = 0;
    int Gastronomia = 0;
    int Marketing = 0;
    int Logistica = 0;

    public Resposta_humanas(String texto, int filosofia, int historia, int pedagogia, int geografia, int jornalismo, int gastronomia, int marketing, int logistica) {
        this.texto = texto;
        Filosofia = filosofia;
        Historia = historia;
        Pedagogia = pedagogia;
        Geografia = geografia;
        Jornalismo = jornalismo;
        Gastronomia = gastronomia;
        Marketing = marketing;
        Logistica = logistica;
    }
}
