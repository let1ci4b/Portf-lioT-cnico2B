package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Questao9 extends AppCompatActivity {
        TextView curso, pgt;
        RadioButton r1, r2, r3, r4, r5, r6, r7, r8;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_questao9);
            curso = findViewById(R.id.curso);
            pgt = findViewById(R.id.pgt);
            r1 = findViewById(R.id.r1);
            r2 = findViewById(R.id.r2);
            r3 = findViewById(R.id.r3);
            r4 = findViewById(R.id.r4);
            r5 = findViewById(R.id.r5);
            r6 = findViewById(R.id.r6);
            r7 = findViewById(R.id.r7);
            r8 = findViewById(R.id.r8);

            getSupportActionBar().hide();
            curso.setText("Áreas do Conhecimento");
            pgt.setText("Sua matéria favorita da escola eram/são:");
            r1.setText("Artes.");
            r2.setText("Matemática.");
            r3.setText("História e/ou geografia e/ou filosofia.");
            r4.setText("Português e/ou línguas estrangeiras.");
            r5.setText("Química.");
            r6.setText("Física.");
            r7.setText("Biologia.");
            r8.setVisibility(View.INVISIBLE);
        }

        public void muda_tela9(View v){
            Intent mt = new Intent(this, Questao10.class);
            if(r1.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else if(r2.isChecked()){
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else if (r3.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            }
            else if (r4.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else if(r5.isChecked()){
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 1;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else if (r6.isChecked()){
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else if (r7.isChecked()){
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            }
            else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onBackPressed() {
            Toast.makeText(this, "Não é possível voltar", Toast.LENGTH_SHORT).show();
        }
    }