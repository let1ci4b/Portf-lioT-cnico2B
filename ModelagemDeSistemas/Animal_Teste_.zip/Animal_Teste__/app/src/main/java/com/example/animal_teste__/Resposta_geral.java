package com.example.animal_teste__;

public class Resposta_geral {
    String texto;
    int Ciencias_exatas = 0;
    int Ciencias_biologicas = 0;
    int Engenharias = 0;
    int Ciencias_saude = 0;
    int Ciencias_agrarias = 0;
    int Linguistica_artes = 0;
    int Ciencias_sociais = 0;
    int Ciencias_humanas = 0;

    public Resposta_geral(String texto, int ciencias_exatas, int ciencias_biologicas, int engenharias, int ciencias_saude, int ciencias_agrarias, int linguistica_artes, int ciencias_sociais, int ciencias_humanas) {
        this.texto = texto;
        Ciencias_exatas = ciencias_exatas;
        Ciencias_biologicas = ciencias_biologicas;
        Engenharias = engenharias;
        Ciencias_saude = ciencias_saude;
        Ciencias_agrarias = ciencias_agrarias;
        Linguistica_artes = linguistica_artes;
        Ciencias_sociais = ciencias_sociais;
        Ciencias_humanas = ciencias_humanas;
    }
}
