package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Questao2 extends AppCompatActivity {
    TextView curso, pgt;
    RadioButton r1, r2, r3, r4, r5, r6, r7, r8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_questao2);
        curso = findViewById(R.id.curso);
        pgt = findViewById(R.id.pgt);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        r4 = findViewById(R.id.r4);
        r5 = findViewById(R.id.r5);
        r6 = findViewById(R.id.r6);
        r7 = findViewById(R.id.r7);
        r8 = findViewById(R.id.r8);

        if (Tela_perguntas.opcao == 1) {
            curso.setText("Áreas do Conhecimento");
            pgt.setText("De modo geral, você não gosta de:");
            r1.setText("Lidar com emoções.");
            r2.setText("Trabalhar sem instruções ou explicações.");
            r3.setText("Trabalhos manuais.");
            r4.setText("Seguir regras ou ter uma rotina.");
            r5.setText("Trabalhos repetitivos.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 2) {
            curso.setText("Ciências Exatas e da Terra");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Realizar pesquisas e análises.");
            r2.setText("Desenvolver análises a partir de experimentos.");
            r3.setText("Trabalhar com tecnologias e dispositivos.");
            r4.setText("Resolver e trabalhar com fórmulas.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 3) {
            curso.setText("Ciências Humanas");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Cozinhar e elaborar receitas.");
            r2.setText("Explicar ou ensinar para outros.");
            r3.setText("Comunicação e interação.");
            r4.setText("Realizar pesquisas.");
            r5.setText("Liderar.");
            r6.setText("Elaborar textos.");
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 4) {
            curso.setText("Ciências Sociais Aplicadas");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Gerir e liderar.");
            r2.setText("Documentar.");
            r3.setText("Mediar conflitos.");
            r4.setText("Reger questões financeiras.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 5) {
            curso.setText("Ciências Biológicas");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Identificar problemas ou erros.");
            r2.setText("Comunicar-se com pessoas.");
            r3.setText("Realizar pesquisas.");
            r4.setText("Trabalhar sob pressão.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 6) {
            curso.setText("Ciências Agrárias");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Trabalhar em equipes.");
            r2.setText("Resolver cálculos.");
            r3.setText("Raciocínios lógicos.");
            r4.setText("Trabalhar com tecnologias.");
            r5.setText("Estudar e fazer pesquisas.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 7) {
            curso.setText("Engenharias");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Trabalhar em equipes.");
            r2.setText("Resolver cálculos.");
            r3.setText("Raciocínios lógicos.");
            r4.setText("Trabalhar com tecnologias.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 8) {
            curso.setText("Linguística, letras e artes");
            pgt.setText("Você tem mais facilidade em:");
            r1.setText("Estudar e compreender relações históricas.");
            r2.setText("Conhecimentos estéticos audiovisuais.");
            r3.setText("Refletir criticamente o funcionamento de algo.");
            r4.setText("Conhecimentos musicais.");
            r5.setText("Expressões artísticas.");
            r6.setText("Manipulação de tecnologias.");
            r7.setText("Expressões corporais.");
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 9) {
            curso.setText("Ciências da Saúde");
            pgt.setText("Você tem mais facilidade em:");
            r2.setText("Ouvir e fazer um diagnóstico.");
            r3.setText("Prestar atenção aos detalhes e interpretar pessoas.");
            r4.setText("Fazer coisas na área da química.");
            r1.setText("Supervisionar e auxiliar pessoas.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }
    }

    public void muda_tela2(View v) {
        Intent mt = new Intent(this, Questao3.class);
        if (Tela_perguntas.opcao == 1) {
            if (r1.isChecked()) {
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] -= 1;
                Resultado.areas_geral[2] += 2;
                Resultado.areas_geral[3] -= 1;
                Resultado.areas_geral[4] += 2;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] -= 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 2;
                Resultado.areas_geral[5] -= 1;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] -= 1;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 2;
                Resultado.areas_geral[2] -= 1;
                Resultado.areas_geral[3] -= 1;
                Resultado.areas_geral[4] -= 1;
                Resultado.areas_geral[5] -= 1;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] -= 1;
                Resultado.areas_geral[2] -= 1;
                Resultado.areas_geral[3] -= 1;
                Resultado.areas_geral[4] -= 1;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] -= 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] -= 1;
                Resultado.areas_geral[2] -= 1;
                Resultado.areas_geral[3] -= 1;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 2) {
            if (r1.isChecked()) {
                Resultado.areas_terra[0] += 1;
                Resultado.areas_terra[1] += 1;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 2;
                Resultado.areas_terra[4] += 1;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 1;
                Resultado.areas_terra[3] -= 1;
                Resultado.areas_terra[4] += 2;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_terra[0] += 2;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 1;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_terra[0] += 1;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 2;
                Resultado.areas_terra[3] += 2;
                Resultado.areas_terra[4] += 1;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 3) {
            if (r1.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 2;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 2;
                Resultado.areas_humanas[2] += 2;
                Resultado.areas_humanas[3] += 2;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_humanas[0] += 1;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 2;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 2;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 2;
                Resultado.areas_humanas[7] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 2;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 2;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 2;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 1;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 2;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 4) {
            if (r1.isChecked()) {
                Resultado.areas_sociais[0] += 2;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_sociais[0] += 1;
                Resultado.areas_sociais[1] += 2;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 1;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 2;
                Resultado.areas_sociais[4] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 2;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 5) {
            if (r1.isChecked()) {
                Resultado.areas_biologicas[0] += 0;
                Resultado.areas_biologicas[1] += 2;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 2;
                Resultado.areas_biologicas[4] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_biologicas[0] += 2;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 2;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_biologicas[0] += 0;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 2;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_biologicas[0] += 1;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 2;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 6) {
            if (r1.isChecked()) {
                Resultado.areas_agrarias[0] += 2;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 0;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 2;
                Resultado.areas_agrarias[3] += 2;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 1;
                Resultado.areas_agrarias[2] += 2;
                Resultado.areas_agrarias[3] += 2;
                Resultado.areas_agrarias[4] += 1;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_agrarias[0] += 1;
                Resultado.areas_agrarias[1] += 2;
                Resultado.areas_agrarias[2] += 1;
                Resultado.areas_agrarias[3] += 1;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_agrarias[0] += 1;
                Resultado.areas_agrarias[1] += 2;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 0;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 7) {
            if (r1.isChecked()) {
                Resultado.areas_engenharias[0] += 2;
                Resultado.areas_engenharias[1] += 2;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_engenharias[0] += 2;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 2;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_engenharias[0] += 1;
                Resultado.areas_engenharias[1] += 0;
                Resultado.areas_engenharias[2] += 1;
                Resultado.areas_engenharias[3] += 1;
                Resultado.areas_engenharias[4] += 1;
                Resultado.areas_engenharias[5] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 2;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 2;
                Resultado.areas_engenharias[4] += 1;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 8) {
            if (r1.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 1;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 1;
                Resultado.areas_artes[5] += 1;
                Resultado.areas_artes[6] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 2;
                Resultado.areas_artes[4] += 1;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 2;
                Resultado.areas_artes[6] += 1;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 1;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 2;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_artes[0] += 2;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 1;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r6.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 2;
                Resultado.areas_artes[3] += 2;
                Resultado.areas_artes[4] += 1;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r7.isChecked()) {
                Resultado.areas_artes[0] += 1;
                Resultado.areas_artes[1] += 2;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 9) {
            if (r1.isChecked()) {
                Resultado.areas_saude[0] += 1;
                Resultado.areas_saude[1] += 2;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 1;
                Resultado.areas_saude[5] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_saude[0] += 2;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 2;
                Resultado.areas_saude[4] += 1;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 1;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 2;
                Resultado.areas_saude[5] += 1;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 2;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Não é possível voltar", Toast.LENGTH_SHORT).show();
    }
}