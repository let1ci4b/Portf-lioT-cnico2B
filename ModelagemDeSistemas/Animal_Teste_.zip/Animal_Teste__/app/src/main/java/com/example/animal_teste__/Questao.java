package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Questao extends AppCompatActivity {
    TextView curso, pgt;
    RadioButton r1, r2, r3, r4, r5, r6, r7, r8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_questoes);
        curso = findViewById(R.id.curso);
        pgt = findViewById(R.id.pgt);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        r4 = findViewById(R.id.r4);
        r5 = findViewById(R.id.r5);
        r6 = findViewById(R.id.r6);
        r7 = findViewById(R.id.r7);
        r8 = findViewById(R.id.r8);

        if (Tela_perguntas.opcao == 1) {
            curso.setText("Áreas do Conhecimento");
            pgt.setText("Quando faz um trabalho em grupo, você é aquele(a) que:");
            r1.setText("Quer ir direto ao ponto.");
            r2.setText("Segue as ideias já propostas.");
            r3.setText("Analisa bem o trabalho antes de agir.");
            r4.setText("É o(a) que faz uma apresentação surpreendente e tocante.");
            r5.setText("Junta as ideias do grupo  e encontra uma solução.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 2) {
            curso.setText("Ciências Exatas e da Terra");
            pgt.setText("Você é considerado mais:");
            r1.setText("Disciplinado.");
            r2.setText("Competitivo.");
            r3.setText("Comunicativo.");
            r4.setText("Dinâmico.");
            r5.setText("Curioso e/ou estudioso.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 3) {
            curso.setText("Ciências Humanas");
            pgt.setText("Você é considerado mais:");
            r1.setText("Estudioso e observador.");
            r2.setText("Criativo.");
            r3.setText("Orientador.");
            r4.setText("Ético.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 4) {
            curso.setText("Ciências Sociais Aplicadas");
            pgt.setText("Você é considerado mais:");
            r1.setText("Analítico.");
            r2.setText("Justo.");
            r3.setText("Líder.");
            r4.setText("Organizado.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 5) {
            curso.setText("Ciências Biológicas");
            pgt.setText("Você é considerado mais:");
            r1.setText("Comunicativo.");
            r2.setText("Mediador.");
            r3.setText("Empático.");
            r4.setText("Investigador.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 6) {
            curso.setText("Ciências Agrárias");
            pgt.setText("Você é considerado mais:");
            r1.setText("Prático.");
            r2.setText("Estudioso e observador.");
            r3.setText("Analista.");
            r4.setText("Curioso.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 7) {
            curso.setText("Engenharias");
            pgt.setText("Você é considerado mais:");
            r1.setText("Curioso.");
            r2.setText("Sistemático.");
            r3.setText("Organizado.");
            r4.setText("Lógico.");
            r5.setVisibility(View.INVISIBLE);
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 8) {
            curso.setText("Linguística, letras e artes");
            pgt.setText("Você é considerado mais:");
            r1.setText("Expressivo.");
            r2.setText("Comunicativo.");
            r3.setText("Observador.");
            r4.setText("Organizado.");
            r5.setText("Estudioso e/ou crítico.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }

        if (Tela_perguntas.opcao == 9) {
            curso.setText("Ciências da Saúde");
            pgt.setText("Você é considerado mais:");
            r1.setText("Ético.");
            r2.setText("Bom ouvinte.");
            r3.setText("Prático.");
            r4.setText("Detalhista.");
            r5.setText("Comunicativo.");
            r6.setVisibility(View.INVISIBLE);
            r7.setVisibility(View.INVISIBLE);
            r8.setVisibility(View.INVISIBLE);
        }
    }

    public void muda_tela1(View v) {
        Intent mt = new Intent(this, Questao2.class);
        if (Tela_perguntas.opcao == 1) {
            if (r1.isChecked()) {
                Resultado.areas_geral[0] += 2;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 1;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
                finish();
            } else if (r2.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 1;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 2;
                Resultado.areas_geral[4] += 2;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_geral[0] += 0;
                Resultado.areas_geral[1] += 1;
                Resultado.areas_geral[2] += 0;
                Resultado.areas_geral[3] += 1;
                Resultado.areas_geral[4] += 0;
                Resultado.areas_geral[5] += 2;
                Resultado.areas_geral[6] += 0;
                Resultado.areas_geral[7] += 2;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_geral[0] += 1;
                Resultado.areas_geral[1] += 0;
                Resultado.areas_geral[2] += 1;
                Resultado.areas_geral[3] += 0;
                Resultado.areas_geral[4] += 1;
                Resultado.areas_geral[5] += 0;
                Resultado.areas_geral[6] += 2;
                Resultado.areas_geral[7] += 0;
                startActivity(mt);
            } else if (isFinishing()) {
                Toast.makeText(this, "Não é possível voltar", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 2) {
            if (r1.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 2;
                Resultado.areas_terra[2] += 2;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_terra[0] += 2;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 2;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 2;
                Resultado.areas_terra[4] += 0;
                Resultado.areas_terra[5] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_terra[0] += 2;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 0;
                Resultado.areas_terra[3] += 0;
                Resultado.areas_terra[4] += 2;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_terra[0] += 0;
                Resultado.areas_terra[1] += 0;
                Resultado.areas_terra[2] += 2;
                Resultado.areas_terra[3] += 2;
                Resultado.areas_terra[4] += 2;
                Resultado.areas_terra[5] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 3) {
            if (r1.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 2;
                Resultado.areas_humanas[2] += 2;
                Resultado.areas_humanas[3] += 2;
                Resultado.areas_humanas[4] += 2;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 0;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 2;
                Resultado.areas_humanas[6] += 2;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_humanas[0] += 0;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 1;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_humanas[0] += 2;
                Resultado.areas_humanas[1] += 0;
                Resultado.areas_humanas[2] += 2;
                Resultado.areas_humanas[3] += 0;
                Resultado.areas_humanas[4] += 0;
                Resultado.areas_humanas[5] += 0;
                Resultado.areas_humanas[6] += 0;
                Resultado.areas_humanas[7] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 4) {
            if (r1.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 2;
                Resultado.areas_sociais[3] += 1;
                Resultado.areas_sociais[4] += 1;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_sociais[0] += 0;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 2;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_sociais[0] += 2;
                Resultado.areas_sociais[1] += 0;
                Resultado.areas_sociais[2] += 0;
                Resultado.areas_sociais[3] += 1;
                Resultado.areas_sociais[4] += 1;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_sociais[0] += 2;
                Resultado.areas_sociais[1] += 2;
                Resultado.areas_sociais[2] += 1;
                Resultado.areas_sociais[3] += 0;
                Resultado.areas_sociais[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 5) {
            if (r1.isChecked()) {
                Resultado.areas_biologicas[0] += 2;
                Resultado.areas_biologicas[1] += 1;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_biologicas[0] += 2;
                Resultado.areas_biologicas[1] += 2;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_biologicas[0] += 1;
                Resultado.areas_biologicas[1] += 0;
                Resultado.areas_biologicas[2] += 0;
                Resultado.areas_biologicas[3] += 2;
                Resultado.areas_biologicas[4] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_biologicas[0] += 1;
                Resultado.areas_biologicas[1] += 2;
                Resultado.areas_biologicas[2] += 2;
                Resultado.areas_biologicas[3] += 0;
                Resultado.areas_biologicas[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 6) {
            if (r1.isChecked()) {
                Resultado.areas_agrarias[0] += 1;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 2;
                Resultado.areas_agrarias[3] += 2;
                Resultado.areas_agrarias[4] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 2;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 0;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_agrarias[0] += 1;
                Resultado.areas_agrarias[1] += 0;
                Resultado.areas_agrarias[2] += 2;
                Resultado.areas_agrarias[3] += 2;
                Resultado.areas_agrarias[4] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_agrarias[0] += 0;
                Resultado.areas_agrarias[1] += 2;
                Resultado.areas_agrarias[2] += 0;
                Resultado.areas_agrarias[3] += 0;
                Resultado.areas_agrarias[4] += 0;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 7) {
            if (r1.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 0;
                Resultado.areas_engenharias[2] += 2;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 2;
                Resultado.areas_engenharias[5] += 2;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_engenharias[0] += 2;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 1;
                Resultado.areas_engenharias[4] += 1;
                Resultado.areas_engenharias[5] += 1;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_engenharias[0] += 1;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 2;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_engenharias[0] += 0;
                Resultado.areas_engenharias[1] += 1;
                Resultado.areas_engenharias[2] += 0;
                Resultado.areas_engenharias[3] += 0;
                Resultado.areas_engenharias[4] += 0;
                Resultado.areas_engenharias[5] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 8) {
            if (r1.isChecked()) {
                Resultado.areas_artes[0] += 2;
                Resultado.areas_artes[1] += 2;
                Resultado.areas_artes[2] += 1;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 2;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 2;
                Resultado.areas_artes[2] += 2;
                Resultado.areas_artes[3] += 0;
                Resultado.areas_artes[4] += 2;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 1;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_artes[0] += 2;
                Resultado.areas_artes[1] += 1;
                Resultado.areas_artes[2] += 1;
                Resultado.areas_artes[3] += 2;
                Resultado.areas_artes[4] += 2;
                Resultado.areas_artes[5] += 0;
                Resultado.areas_artes[6] += 0;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 1;
                Resultado.areas_artes[2] += 1;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 2;
                Resultado.areas_artes[6] += 1;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_artes[0] += 0;
                Resultado.areas_artes[1] += 0;
                Resultado.areas_artes[2] += 0;
                Resultado.areas_artes[3] += 1;
                Resultado.areas_artes[4] += 0;
                Resultado.areas_artes[5] += 2;
                Resultado.areas_artes[6] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
        if (Tela_perguntas.opcao == 9) {
            if (r1.isChecked()) {
                Resultado.areas_saude[0] += 2;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 2;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 1;
                startActivity(mt);
            } else if (r2.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 2;
                Resultado.areas_saude[5] += 0;
                startActivity(mt);
            } else if (r3.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 2;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 2;
                startActivity(mt);
            } else if (r4.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 2;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 1;
                startActivity(mt);
            } else if (r5.isChecked()) {
                Resultado.areas_saude[0] += 0;
                Resultado.areas_saude[1] += 0;
                Resultado.areas_saude[2] += 0;
                Resultado.areas_saude[3] += 0;
                Resultado.areas_saude[4] += 0;
                Resultado.areas_saude[5] += 2;
                startActivity(mt);
            } else {
                Toast.makeText(this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Não é possível voltar", Toast.LENGTH_SHORT).show();
    }
}