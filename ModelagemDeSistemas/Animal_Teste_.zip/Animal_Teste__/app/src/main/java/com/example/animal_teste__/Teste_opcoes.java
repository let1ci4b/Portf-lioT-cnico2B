package com.example.animal_teste__;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Teste_opcoes extends AppCompatActivity {
    TextView curso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teste_opcoes);
        getSupportActionBar().hide();
        curso = findViewById(R.id.curso);
    }

    public void iniciar_especifico(View view) {
        Intent ini_esp = new Intent(this, Teste_areas.class);
        startActivity(ini_esp);
    }

    public void iniciar_area(View view) {
        Intent ini_area = new Intent(this, Tela_perguntas.class);
        startActivity(ini_area);
        Tela_perguntas.opcao = 1;
    }

    public void perfil(View view) {
        Intent p = new Intent(this, Perfil.class);
        startActivity(p);
    }
}