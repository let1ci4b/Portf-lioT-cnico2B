package com.example.animal_teste__;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Perfil extends AppCompatActivity {
    TextView eusu, nusu;
    static String nome;
    static String email;
    ImageView img;
    ImageView fotoPerfil;
    static int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_perfil);
        eusu = findViewById(R.id.email_perfil);
        nusu = findViewById(R.id.nome);
        eusu.setText(email);
        nusu.setText(nome);
        fotoPerfil = findViewById(R.id.fotoPerfil);
        fotoPerfil.setVisibility(View.VISIBLE);
        Resultado.fotoPerfil = fotoPerfil;
        fotoPerfil = findViewById(R.id.fotoPerfil);
        img = findViewById(R.id.img);
        {
            imagem();
        }

        if (Tela_perguntas.opcao == 1) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.cieexatas);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.biologicas);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.engenharias);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.ciesaude);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.cieagrarias);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.letrasartes);
            } else if (res == 6) {
                fotoPerfil.setImageResource(R.drawable.ciesociais);
            } else if (res == 7) {
                fotoPerfil.setImageResource(R.drawable.ciehumanas);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 2) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.ciecomputacao);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.cienaturais);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.fisica);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.matematica);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.quimica);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.astronomia);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 5) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.gestaoambiental);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.vigsanitaria);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.biomedicina);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.veterinaria);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.nutricao);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 7) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.engcivil);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.engeletrica);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.engambiental);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.engproducao);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.engquimica);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.engsoftware);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 9) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.medicina);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.enfermagem);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.farmacia);
            } else if (res == 3) {
                img.setImageResource(R.drawable.odontologia);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.psicologia);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.edfisica);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

            if (Tela_perguntas.opcao == 6) {
                if (res == 0) {
                    fotoPerfil.setImageResource(R.drawable.agronomia);
                } else if (res == 1) {
                    fotoPerfil.setImageResource(R.drawable.ecologia);
                } else if (res == 2) {
                    fotoPerfil.setImageResource(R.drawable.engagricola);
                } else if (res == 3) {
                    fotoPerfil.setImageResource(R.drawable.engpesca);
                } else if (res == 4) {
                    fotoPerfil.setImageResource(R.drawable.geologia);
                } else {
                    fotoPerfil.setImageResource(R.drawable.administracao);
                }
            }

        if (Tela_perguntas.opcao == 8) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.artes);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.danca);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.design);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.cinema);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.musica);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.linguistica);
            } else if (res == 6) {
                fotoPerfil.setImageResource(R.drawable.letras);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 4) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.administracao);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.biblioteconomia);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.contabeis);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.comexterior);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.direito);
            } else {
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }

        if (Tela_perguntas.opcao == 3) {
            if (res == 0) {
                fotoPerfil.setImageResource(R.drawable.filosofia);
            } else if (res == 1) {
                fotoPerfil.setImageResource(R.drawable.historia);
            } else if (res == 2) {
                fotoPerfil.setImageResource(R.drawable.pedagogia);
            } else if (res == 3) {
                fotoPerfil.setImageResource(R.drawable.geografia);
            } else if (res == 4) {
                fotoPerfil.setImageResource(R.drawable.jornalismo);
            } else if (res == 5) {
                fotoPerfil.setImageResource(R.drawable.gastronomia);
            } else if (res == 6) {
                fotoPerfil.setImageResource(R.drawable.marketing);
            } else if (res == 7) {
                fotoPerfil.setImageResource(R.drawable.logistica);
            } else
                fotoPerfil.setImageResource(R.drawable.administracao);
            }
        }


    public void imagem(){
        ViewGroup.LayoutParams tamanho = img.getLayoutParams();
        tamanho.height = 800;
        tamanho.width = 800;
        img.setLayoutParams(tamanho);
        img.setImageResource(R.drawable.img62878248a1b0a6_81562800);
    }

    public void sair(View view) {
        Intent s = new Intent(this, MainActivity.class);
        startActivity(s);
    }

    public void click(View view) {
        Random ramon = new Random();
        int g = ramon.nextInt(56)+1;
        ViewGroup.LayoutParams tamanho = img.getLayoutParams();
        tamanho.height = 800;
        tamanho.width = 800;
        img.setLayoutParams(tamanho);
        if(g == 1) {
            img.setImageResource(R.drawable.biologicas);
        }
        else if(g == 2) {
            img.setImageResource(R.drawable.cieexatas);
        }
        else if(g == 3) {
            img.setImageResource(R.drawable.engenharias);
        }
        else if(g == 4) {
            img.setImageResource(R.drawable.ciesaude);
        }
        else if(g == 5) {
            img.setImageResource(R.drawable.cieagrarias);
        }
        else if(g == 6) {
            img.setImageResource(R.drawable.letrasartes);
        }
        else if(g == 7) {
            img.setImageResource(R.drawable.ciesociais);
        }
        else if(g == 8) {
            img.setImageResource(R.drawable.humanas);
        }
        else if(g == 9) {
            img.setImageResource(R.drawable.ciecomputacao);
        }
        else if(g == 10) {
            img.setImageResource(R.drawable.cienaturais);
        }
        else if(g == 11) {
            img.setImageResource(R.drawable.fisica);
        }
        else if(g == 12) {
            img.setImageResource(R.drawable.matematica);
        }
        else if(g == 13) {
            img.setImageResource(R.drawable.quimica);
        }
        else if(g == 14) {
            img.setImageResource(R.drawable.astronomia);
        }
        else if(g == 15) {
            img.setImageResource(R.drawable.gestaoambiental);
        }
        else if(g == 16) {
            img.setImageResource(R.drawable.vigsanitaria);
        }
        else if(g == 17) {
            img.setImageResource(R.drawable.psicologia);
        }
        else if(g == 18) {
            img.setImageResource(R.drawable.veterinaria);
        }
        else if(g == 19) {
            img.setImageResource(R.drawable.nutricao);
        }
        else if(g == 20) {
            img.setImageResource(R.drawable.engcivil);
        }
        else if(g == 21) {
            img.setImageResource(R.drawable.engeletrica);
        }
        else if(g == 22) {
            img.setImageResource(R.drawable.engambiental);
        }
        else if(g == 23) {
            img.setImageResource(R.drawable.engproducao);
        }
        else if(g == 24) {
            img.setImageResource(R.drawable.engquimica);
        }
        else if(g == 25) {
            img.setImageResource(R.drawable.engsoftware);
        }
        else if(g == 26) {
            img.setImageResource(R.drawable.medicina);
        }
        else if(g == 27) {
            img.setImageResource(R.drawable.enfermagem);
        }
        else if(g == 28) {
            img.setImageResource(R.drawable.farmacia);
        }
        else if(g == 29) {
            img.setImageResource(R.drawable.odontologia);
        }
        else if(g == 30) {
            img.setImageResource(R.drawable.psicologia);
        }
        else if(g == 31) {
            img.setImageResource(R.drawable.edfisica);
        }
        else if(g == 32) {
            img.setImageResource(R.drawable.agronomia);
        }
        else if(g == 33) {
            img.setImageResource(R.drawable.ecologia);
        }
        else if(g == 34) {
            img.setImageResource(R.drawable.engagricola);
        }
        else if(g == 35) {
            img.setImageResource(R.drawable.engpesca);
        }
        else if(g == 36) {
            img.setImageResource(R.drawable.geologia);
        }
        else if(g == 37) {
            img.setImageResource(R.drawable.artes);
        }
        else if(g == 38) {
            img.setImageResource(R.drawable.danca);
        }
        else if(g == 39) {
            img.setImageResource(R.drawable.design);
        }
        else if(g == 40) {
            img.setImageResource(R.drawable.cinema);
        }
        else if(g == 41) {
            img.setImageResource(R.drawable.musica);
        }
        else if(g == 42) {
            img.setImageResource(R.drawable.linguistica);
        }
        else if(g == 43) {
            img.setImageResource(R.drawable.letras);
        }
        else if(g == 44) {
            img.setImageResource(R.drawable.administracao);
        }
        else if(g == 45) {
            img.setImageResource(R.drawable.biblioteconomia);
        }
        else if(g == 46) {
            img.setImageResource(R.drawable.contabeis);
        }
        else if(g == 47) {
            img.setImageResource(R.drawable.comexterior);
        }
        else if(g == 48) {
            img.setImageResource(R.drawable.direito);
        }
        else if(g == 49) {
            img.setImageResource(R.drawable.filosofia);
        }
        else if(g == 50) {
            img.setImageResource(R.drawable.historia);
        }
        else if(g == 51) {
            img.setImageResource(R.drawable.pedagogia);
        }
        else if(g == 52) {
            img.setImageResource(R.drawable.geografia);
        }
        else if(g == 53) {
            img.setImageResource(R.drawable.jornalismo);
        }
        else if(g == 54) {
            img.setImageResource(R.drawable.gastronomia);
        }
        else if(g == 55) {
            img.setImageResource(R.drawable.marketing);
        }
        else if(g == 56) {
            img.setImageResource(R.drawable.logistica);
        }
    }
}