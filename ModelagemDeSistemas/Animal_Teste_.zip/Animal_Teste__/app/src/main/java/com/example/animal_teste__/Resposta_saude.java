package com.example.animal_teste__;

public class Resposta_saude {
    String texto;
    int Medicina = 0;
    int Enfermagem = 0;
    int Farmacia = 0;
    int Odontologia = 0;
    int Psicologia = 0;
    int Educacao_fisica = 0;

    public Resposta_saude(String texto, int medicina, int enfermagem, int farmacia, int odontologia, int psicologia, int educacao_fisica) {
        this.texto = texto;
        Medicina = medicina;
        Enfermagem = enfermagem;
        Farmacia = farmacia;
        Odontologia = odontologia;
        Psicologia = psicologia;
        Educacao_fisica = educacao_fisica;
    }
}
