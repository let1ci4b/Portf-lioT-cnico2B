package com.example.animal_teste__;

public class Resposta_exatas {
    String texto;
    int Ciencias_computacao = 0;
    int Ciencias_naturais = 0;
    int Fisica= 0;
    int Matematica = 0;
    int Quimica = 0;
    int Astromomia= 0;

    public Resposta_exatas(String texto, int ciencias_computacao, int ciencias_naturais, int fisica, int matematica, int quimica, int astromomia) {
        this.texto = texto;
        Ciencias_computacao = ciencias_computacao;
        Ciencias_naturais = ciencias_naturais;
        Fisica = fisica;
        Matematica = matematica;
        Quimica = quimica;
        Astromomia = astromomia;
    }
}
