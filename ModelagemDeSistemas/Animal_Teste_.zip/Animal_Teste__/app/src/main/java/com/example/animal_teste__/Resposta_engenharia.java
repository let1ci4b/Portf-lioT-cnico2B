package com.example.animal_teste__;

public class Resposta_engenharia {
    String texto;
    int Engenharia_civil = 0;
    int Engenharia_eletrica = 0;
    int Engenharia_ambiental = 0;
    int Engenharia_producao = 0;
    int Engenharia_quimica = 0;
    int Engenharia_software = 0;

    public Resposta_engenharia(String texto, int engenharia_civil, int engenharia_eletrica, int engenharia_ambiental, int engenharia_producao, int engenharia_quimica, int engenharia_software) {
        this.texto = texto;
        Engenharia_civil = engenharia_civil;
        Engenharia_eletrica = engenharia_eletrica;
        Engenharia_ambiental = engenharia_ambiental;
        Engenharia_producao = engenharia_producao;
        Engenharia_quimica = engenharia_quimica;
        Engenharia_software = engenharia_software;
    }
}
